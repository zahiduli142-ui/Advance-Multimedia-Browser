# Advance Multimedia (GitHub-ready)

This package contains everything needed to build the Advance Multimedia Browser installer via GitHub Actions.

Files included:
- logo.png
- advanced_multimedia_installer_builder.zip (the Electron app source)
- .github/workflows/build.yml (workflow to build the installer on GitHub)

Upload the contents of this ZIP to your GitHub repository, then go to Actions -> Build Advance Multimedia Installer -> Run workflow.
